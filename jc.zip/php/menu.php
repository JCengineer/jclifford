<div class="menu">
	<a href="software.php">
		<div class="panel pL">
			<h3>Software</h3>
		</div>
	</a>
	<a href="hardware.php">
		<div class="panel pL">
			<h3>Hardware</h3>
		</div>
	</a>
	<a href="business.php">
		<div class="panel pL">
			<h3>Business</h3>
		</div>
	</a>
	<a href="build.php">
		<div class="panel pL">
			<h3>Building</h3>
		</div>
	</a>
	<a href="event.php">
		<div class="panel pL">
			<h3>Events</h3>
		</div>
	</a>
	<div class="panel pC">
		<h3>Like what you see?</h3><br>
		<a href="contact.php" class="callToAction secondary" style="margin:5px;">Contact</a>
	</div>
</div>