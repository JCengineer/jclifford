<footer>
	<div class="links">
		<a href="/"><h2>JClifford</h2></a>|
		<a href="tour.php"><h3>Tour</h3></a>|
		<a href="contact.php"><h3>Contact</h3></a>
	</div>

	<!--todo media player here-->

	<div class="buttons">
		<!--<a href="https://twitter.com/jamescaudio" class="twitter-follow-button" data-show-count="false">Follow @jamescaudio</a>
		<br>
		<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+'://platform.twitter.com/widgets.js';fjs.parentNode.insertBefore(js,fjs);}}(document, 'script', 'twitter-wjs');</script>
		<div class="fb-like" data-href="https://www.facebook.com/Visilit" data-layout="button" data-action="like" data-show-faces="true" data-share="true"></div>
		-->
		<a href="http://ie.linkedin.com/in/jcengineer" target="_blank	">
        	<img src="https://static.licdn.com/scds/common/u/img/webpromo/btn_myprofile_160x33.png" width="160" height="33" border="0" alt="View James Clifford's profile on LinkedIn">
    	</a>
	</div>
</footer>

<!-- javascript -->
<script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
<script src="lib/magnific-popup/mp.js"></script>
<script src="js/ui.js"></script>
<script src="js/tour.js"></script>