<header class="clearfix">
	<div>
		<h1>James Clifford - Engineering &amp; Development Services</h1>
		<h2>My online CV, portfolio, idea pad and blog...</h2>
		<h3>I have experience with web and app development,<br>
		computer and electronic engineering,<br>
		start up and small/medium business development,<br>
		rapid prototyping and building/fixing.</h3>
		<br>
		<a href="tour.php" class="callToAction">Take a tour</a>
		<a href="contact.php" class="callToAction secondary">Send me a mail</a>

	</div>
	<img src="media/jc-profile.png" />
</header>