<div id="summary">
	<div id="gallery" class="gallery">
		<div id="galleryscroller" class="scrollerdiv">
			<span class="category software" data-forlink="software.php">Software</span>
			<div 	id="headerPic1" class="image"  style='background:url("media/gallery/gallery1 (1).jpg");background-size:cover;'
					title="James Clifford - Gallery." 				href="media/gallery/gallery1 (1).jpg"></div>
			<div 	id="headerPic2" class="image"  style='background:url("media/gallery/gallery1 (2).jpg");background-size:cover;'
					title="James Clifford - Gallery." 				href="media/gallery/gallery1 (2).jpg"></div>
			<div 	id="headerPic3" class="image"  style='background:url("media/gallery/gallery1 (3).jpg");background-size:cover;'
					title="James Clifford - Gallery." 				href="media/gallery/gallery1 (3).jpg"></div>
			<div 	id="headerPic4" class="image"  style='background:url("media/gallery/gallery1 (4).jpg");background-size:cover;'
					title="James Clifford - Gallery." 				href="media/gallery/gallery1 (4).jpg"></div>
			<span class="category hardware" data-forlink="hardware.php">Hardware</span>
			<div 	id="headerPic5" class="image"  style='background:url("media/gallery/gallery1 (5).jpg");background-size:cover;'
					title="James Clifford - Gallery." 				href="media/gallery/gallery1 (5).jpg"></div>
			<div 	id="headerPic6" class="image"  style='background:url("media/gallery/gallery1 (6).jpg");background-size:cover;'
					title="James Clifford - Gallery." 				href="media/gallery/gallery1 (6).jpg"></div>
			<div 	id="headerPic7" class="image"  style='background:url("media/gallery/gallery1 (7).jpg");background-size:cover;'
					title="James Clifford - Gallery." 				href="media/gallery/gallery1 (7).jpg"></div>
			<div 	id="headerPic8" class="image"  style='background:url("media/gallery/gallery1 (8).jpg");background-size:cover;'
					title="James Clifford - Gallery." 				href="media/gallery/gallery1 (8).jpg"></div>
			<div 	id="headerPic1" class="image"  style='background:url("media/gallery/gallery1 (1).jpg");background-size:cover;'
					title="James Clifford - Gallery." 				href="media/gallery/gallery1 (1).jpg"></div>
			<span class="category business" data-forlink="business.php">Business</span>
			<div 	id="headerPic2" class="image"  style='background:url("media/gallery/gallery1 (2).jpg");background-size:cover;'
					title="James Clifford - Gallery." 				href="media/gallery/gallery1 (2).jpg"></div>
			<div 	id="headerPic3" class="image"  style='background:url("media/gallery/gallery1 (3).jpg");background-size:cover;'
					title="James Clifford - Gallery." 				href="media/gallery/gallery1 (3).jpg"></div>
			<div 	id="headerPic4" class="image"  style='background:url("media/gallery/gallery1 (4).jpg");background-size:cover;'
					title="James Clifford - Gallery." 				href="media/gallery/gallery1 (4).jpg"></div>
			<span class="category build" data-forlink="build.php">Building</span>
			<div 	id="headerPic5" class="image"  style='background:url("media/gallery/gallery1 (5).jpg");background-size:cover;'
					title="James Clifford - Gallery." 				href="media/gallery/gallery1 (5).jpg"></div>
			<div 	id="headerPic6" class="image"  style='background:url("media/gallery/gallery1 (6).jpg");background-size:cover;'
					title="James Clifford - Gallery." 				href="media/gallery/gallery1 (6).jpg"></div>
			<span class="category events" data-forlink="event.php">Events</span>
			<div 	id="headerPic7" class="image"  style='background:url("media/gallery/gallery1 (7).jpg");background-size:cover;'
					title="James Clifford - Gallery." 				href="media/gallery/gallery1 (7).jpg"></div>
			<div 	id="headerPic8" class="image"  style='background:url("media/gallery/gallery1 (8).jpg");background-size:cover;'
					title="James Clifford - Gallery." 				href="media/gallery/gallery1 (8).jpg"></div>
		</div>
		<span class="gradient"></span>
	</div>
	<div class="clearfix">
		<div id="twitterWidget">
			<a class="twitter-timeline" href="https://twitter.com/JCliff_Engineer" data-widget-id="535483630320381952">Tweets by @JCliff_Engineer</a>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
		</div>
		<div class="horizontalList">
			<h2><u>I build things for :</u></h2>
			<h3>Header 1</h3>
			<p>listitem | listitem | listitem | listitem</p>
			<h3>Header 1</h3>
			<p>listitem | listitem | listitem | listitem</p>
			<h3>Header 1</h3>
			<p>listitem | listitem | listitem | listitem</p>
			<h3>Header 1</h3>
			<p>listitem | listitem | listitem</p>
		</div>
	</div>
</div>